File 2 slide 19.

---

![[Pasted image 20231102160438.png]]
*HP*: diodi in conduzione, quindi anodo a 0.7V
*TESI*: scorre corrente $\sim mA$

L'anodo di D1 e D2 dovrà essere a 0.7 o almeno, così D1 conduce. Per questo il catodo di D1 a GND sarà come il catodo di D2, anch'esso a GND.
