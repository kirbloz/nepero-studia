![[Pasted image 20231102161708.png]]

Calcolare $I_c$ e $V_{ce}$ dato $\beta$
Suppongo
*HP*: regione attiva 
*TESI*: $I_{c}= \beta \cdot I_{b}$

Si cerca $I_{b}$ e poi $V_{ce}$
Se $I_{c}$ corrisponde alla tesi allora ok.

---

![[Pasted image 20231102163551.png]]

Calcolare $I_{c}$ e $V_{ce}$ con $\beta=75$
Comodo è scrivere le equazione delle maglie (rami)

*HP*: polarizzazione attiva (calcoli facily)