Nel dominio delle frequenze, la *frequenza di taglio* $\large f_c$ è la frequenza dove l'[[Attenuazione|attenuazione]] è apri a 3dB ovvero è il polo della funzione di trasferimento del primo ordine.[^3]



![[Pasted image 20231009175339.png]][^1]
![[Pasted image 20231009175405.png]][^2]
[^1]: Dal PDF n3 CEE
[^2]: Dal PDF n3 CEE
[^3]: Dal FE_I1