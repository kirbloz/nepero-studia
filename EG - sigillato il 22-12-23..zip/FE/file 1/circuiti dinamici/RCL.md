
Analisi delle [[Impedenze|impedenze]]
![[Pasted image 20231009165757.png]]

#### [[Circuito CR]]
#### [[Circuito RC]]
La costante di tempo $\tau$ è definita come $R\,C$ 


