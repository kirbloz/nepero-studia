La caratteristica è: 
$$\large v(t)=R\,\,i(t)$$
E' un'impedenza resistiva pura. 
Ha comportamento in DC uguale a quello in AC. 
In serie si sommano.