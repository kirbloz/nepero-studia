Il [[UNIVERSITA/CIRCUITI ED ELETTRONICA/FE/file 1/componenti dinamici/Diodo]]
