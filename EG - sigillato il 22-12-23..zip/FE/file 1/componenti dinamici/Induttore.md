IMPEDENZE:
La caratteristica è:
$$\large v = jwL\cdot I$$
E' un'impedenza reattiva pura.
In DC $\omega = 0$ è un corto circuito (impedenza nulla)
In AC $\omega \rightarrow \infty$ è un circuito aperto (impedenza infinita)
In serie si sommano.

---

E' un componente che si oppone alle variazioni di corrente.
La sua relazione caratteristica è $$ \large v(t) = L\frac{di(t)}{dt}$$
- La scelta del verso di riferimento determina il segno: se la corrente entra dal polo positivo allora avrà segno positivo.
- E' un elemento dinamico lineare
- Duale rispetto al condensatore

