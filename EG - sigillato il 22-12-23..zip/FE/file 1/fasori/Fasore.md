Prima incollo due slide di richiami
#### Intro - Richiami
![[Pasted image 20231009175853.png]]![[Pasted image 20231009175903.png]]

### Fasori
FASORE:
 Si definisce fasore **X** associato alla sinusoide a pulsazione (frequenza) $\omega$ il numero complesso tale che 	 $$\large x(t) = Re[\, \overline X\, e^{j\omega t}\,]$$
![[Pasted image 20231011110343.png]]

NB: La frequenza è fissata dunque si lavora nel dominio dei fasori. 

NB: esiste una corrispondenza biunivoca tra sinusoidi isofrequenziali e fasori

#### Calcolo del fasore
![[Pasted image 20231011142935.png]]
![[Pasted image 20231011142909.png]]



