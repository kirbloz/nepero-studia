In polarizzazione diretta è governato da una legge esponenziale$$I=I_{0}(e^{V/nVt}-1)$$
Quando si applica V => scorre I descritta da questa equazione.
Si comporta come un
*Interruttore aperto*: $I \sim I_{0}\sim nA$

### [Diodo Schottky]
L'area (p) è sostituita da del <span style="background:#b1ffff">metallo</span> (conduttore). Per cui la tensione <span style="background:#b1ffff">built-in è minore</span> (0.3) ed è più veloce 

### [Diodi Zener]
Conduce in <span style="background:#b1ffff">polarizzazione inversa</span>. Non ho capito il resto.
La tensione di breakdown è nota e dipende dal drogaggio+temp

### [Diodi led]
In <span style="background:#b1ffff">polarizzazione diretta</span> emette fotoni perchè le coppie p-n si ricombinano, rilasciando energia.
Sono efficienti perchè basta $10mA$ ad accenderli. Il colore indica una tensione diversa.

### [Fotodiodo]
Gli elettroni ricevono energia sia da tensione, temperatura e luce.
*Pol. diretta*: diodo normale.
*Pol. inversa*: il fotone che incide può generare una coppia p-n con energia da superare la $V_0$ built-in. L'energia minima dipende dal materiale.
