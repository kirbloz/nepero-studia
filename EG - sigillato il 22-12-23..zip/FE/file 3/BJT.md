E' un dispositivo costituito da due giunzioni (JC e JE): è un tripolo.
![[Pasted image 20231016222154.png]]
La regione di carica spaziale è molto più larga nel collettore perchè c'è meno concentrazione di atomi ed è più drogata (n).

La regione di carica spaziale in (p) si genera per il contributo degli elettroni liberi da entrambe le superfici 
=> la base è una zona molto stretta e le due zone (generate dalle due n) quasi si toccano
=>la base è tutta regione di carica spaziale

---
### Polarizzazione
Vedi nella [[Giunzione PN]] .

**NB**: Le differenze tra le modalità di funzionamento sono date dalla scelta di $V_{BE}$ e $i_{B}$ per pilotare le caratteristiche sconosciute $V_{CE}$ e $i_{C}$.





[^1]: Piccola probabilità di legarsi, sono responsabili delle correnti di perdita, ordine $\sim nA$ 



























