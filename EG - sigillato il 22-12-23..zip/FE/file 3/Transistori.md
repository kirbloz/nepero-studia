I transistori sono dei dispositivi tripoli caratterizzati da due [[Giunzione PN |giunzioni]] pn - np.

Posso essere della tecnologia [[BJT]] oppure [[tMOS]].

Hanno diversi [[Uso dei transistori|impieghi]], e si discrimina il loro comportamento in base alla loro [[Polarizzazione|polarizzazione]].


### Riassunto

- BJT consuma anche staticamente (ha bisogno di avere sempre delle resistenze)
- il MOS consuma solo in commutazione (gate isolato)
- il MOS ha capacità in ingresso
- il MOS è più facile da realizzare e miniaturizzare

BJT
![[Pasted image 20231102174809.png]]Effetto transistore: base stretta, quindi se JC polarizza inversa la RCS diventa grossa e tutta la base è RCS

MOS
![[Pasted image 20231102174910.png]]
Effetto body: se applico un potenziale al gate abbastanza alto la regione drogata p agisce come n (finto drogaggio n) perchè fa separare gli elettroni di molto. Si genera un canale di conduzione.
E' diversa dalla RCS, gli elettroni scorrono e non si legano nè fermano mai.