Modello di [[Amplificatore Operazionale]]. 
Non è più usato perchè si tende a fare le operazioni in DIGITALE, codificando in binario o altro.

Di seguito il modello circuitale per realizzarlo.
![[Pasted image 20231025161042.png]]

Si prevede sempre una retroazione negativa, senza cortocircuito.
Ci sono due tensioni "in ingresso", che vengono "sommate" e riportate invertite, grazie alla *sovrapposizione degli effetti*.