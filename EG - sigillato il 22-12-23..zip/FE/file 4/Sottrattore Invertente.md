Modello di [[Amplificatore Operazionale]]. 
Non è più usato perchè si tende a fare le operazioni in DIGITALE, codificando in binario o altro.

Di seguito il modello circuitale per realizzarlo.
![[Pasted image 20231025161235.png]]

Si prevede sempre una retroazione negativa, senza cortocircuito.

A differenza del sommatore però, questo prevede che il morsetto $V_+$ non sia semplicemente collegato a massa
$\Rightarrow$ portando il morsetto positivo ad un valore diverso da zero, è come se impostassi un **offset**

Le due tensioni "in ingresso", vengono "sottratte" per offset grazie alla *sovrapposizione degli effetti*, e riportate invertite.

### Caso: amplificatore differenziale
Slide 13 file 4.