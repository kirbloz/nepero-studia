Ordine delle cose è: (solo nei miei file)

- Re: bjt e mos
- interruttore
- livelli interruttori

- logiche bipolari
- logiche complesse

- logiche elementari (intro)
- codifica binaria
- logiche a interruttori 
- modello statico
- modello - interruttori
- modello - circuito
	- rigenerazione segnale

- cod bin ## convenzioni
- modello statico ### param stat
	- immunità e fanout
>- modello statico ### ritardi -> modello dinamico

- funzioni logiche
- famiglie logiche
- interruttori ## diodo

- fam log ## RTL
	- cod bin ### tensione o corrente?
- fam log ## DTL
- fam log ## TTL
- fam log ## CMOS
- interfacciamento TTL CMOS

- funzioni logiche ## NAND