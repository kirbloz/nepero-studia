Definita come la capacità di un dispositivo di leggere correttamente il livello di un segnale, e reimmettere in USCITA un valore F(In) migliore, più bello - in accordo alla scala delle tensioni si intende.

>Esempio leggo uno zero schifoso "1.4V" ma poi elaborando (supponiamo dalla tabella di verità io debba emettere 1) sputo fuori "5V". Alternativamente (supponiamo dalla tabella di verità io debba emettere 0) sputo fuori "GND" => questo è il sogno.

---

![[Pasted image 20231101112720.png]]