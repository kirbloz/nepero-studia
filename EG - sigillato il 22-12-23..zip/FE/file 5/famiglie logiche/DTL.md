Altra famiglia logica, integra i Diodi al posto dei BJT, per ovviare al problema dell' "1" debole.

Ci sono quei due diodi con uno contropolarizzato per portare a 1.4V la soglia e per far svuotare velocemente la base.

Boh