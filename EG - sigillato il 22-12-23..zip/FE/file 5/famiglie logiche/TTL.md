La famiglia più famosa, la più duratura.
Sfrutta la tecnologia multiemettitore (AND).
![[Pasted image 20231101222125.png]]

- Ha un carico attivo in uscita rappresentato da R4, T4 e D1
	Rout è grande se l'uscita è "0"; $I_{ol}$ grande
	Rout è piccola se l'uscita è "1"; $T_{plh}$ piccolo

- T3 e T4 sono complementari, lavorano in opposizione di fase

- Tutti i BJT lavorano tra interdizione e saturazione; tranne T4 che lavora in zona attiva => deve essere veloce a spegnersi, non può quindi accumulare troppe cariche in base

- Si introduce D1 per evitare un CC
>Praticamente T2= ON => T3=ON ma da T2 a T4 c'è un percorso a bassa impedenza e quindi esiste un momento in cui anche T4=ON per cui appunto, il CC, grazie alla piccola corrente di T4.
>D1 ha la funzione di sfruttare la sua piccola (minchia) barriera di potenziale per permettere a T4 di spegnersi (?)


---
 a pagina 48 ho l'analisi di comportamento con IN: "1"