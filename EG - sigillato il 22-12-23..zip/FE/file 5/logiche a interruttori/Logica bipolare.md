E' un sottocaso della logica binaria [[Logiche elementari|elementare]].
Invece di codificare in "0" e "1" codifica su "$\pm$ 1", destra sinistra. 
E' un *deviatore a due poli* che si realizza con due interruttori.
<span style="background:#fff88f">In un deviatore scorre sempre corrente.</span>
>Ovvio perchè una selezione deve sempre essere attiva, sennò ho un'uscita di incertezza.

Le codifiche bipolari hanno lo svantaggio di necessitare di un'alimentazione positiva ed una negativa (*dual supply*).


![[Pasted image 20231031213400.png]]![[Pasted image 20231031213407.png]]![[Pasted image 20231031213415.png]]


