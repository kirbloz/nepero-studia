Sono il passo successivo alle [[Logica bipolare|logiche bipolari]].
Non ho mai visto sta roba negli appelli di FE.

## Logica Multilivello
Logica in grado di codificare l'informazione su di una *scala di valori*. 
Se ogni uscita ha $n$ componenti, si dice che il dispositivo codifica con simboli a $n$ valori, quindi si utilizzano *deviatori a n poli*.
![[Pasted image 20231031213830.png]]

## Logica parallela
Logica in grado di effettuare una *codifica instantanea di $n$ logiche binarie indipendenti*: ovvero parallelizza tanti interruttori, ciascuno con il proprio comando.
Possono essere anche $n$ logiche multilivello.
![[Pasted image 20231031213841.png]]

## Logica seriale
Logica che effettua *codifica sequenziale*, cadenzata nel tempo, di $n$ logiche binarie elementare. Sequenzia tanti interruttori.
E' necessario un riferimento temporale, a volte esiste un segnale di clock, trasmesso parallelamente al segnale di codifica, oppure dispositivi che non prevedono clock possono sfruttare la tecnica dell'over-sampling. 

![[UNIVERSITA/CIRCUITI ED ELETTRONICA/SED/imgs/Pasted image 20231031213850.png]]

