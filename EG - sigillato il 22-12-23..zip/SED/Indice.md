: file 2 
- Intro

: file 1
- Interfacciamento
	- Disp Digit
- Modello dinamico
- Regione d'incertezza

: file 2
- Modello Dinamico ### Ritardi
- stadio di uscita speciale
	- open collector
	- tri-state
- buffer
- transceiver

- schmidt trigger
	- circuiti generatori di ritardo
	- circuiti oscillanti

file 3:
boh

file 4:
- MSI
	- SoP
	- AOI
- combinatori
	- encoders/decoders
		- priority encorders
		- demultiplexer
		- multiplexer
	- sommatore
		- carry
		- dimensionamento AOI e LUT
	- moltiplicatore
	- comparatore
- funzione logica
- sequenziali
	- latch tipo D -> meta stabilità
	- reset 
	- FF
- FF ## caratt dinamiche
	- meta stabilità
	- meta stabilità ## circuiti robusti 
- memorie
	- SRAM
	- DRAM
		- SDRAM e DDR SDRAM
	- ROM
		- Mask programmed
		- EPROM
		- EEPROM
		- Flash EEPROM
- disp sequenziali 
	- contatori a/sincroni
- disp combinatori ## verso i sequenziali
- disp sequenziali
	- shift register

file 5:
- segnali
- sistemi embedded
	- processore -> MCU
	- memorie
	- periferiche 
		- IO -> GPIO
- MCU
- GPIO
- UART
- interfacce usb
- interfacce seriali
	- SPI -> I^2C
- timing processing unit
	- hardware di cattura
	- hardware comparatore
- segnali ## analogici
- elaborazione analogica
	- ADC
		- sigma/delta
	- DAC
		- pwm
- Msistemi embedded ## collegamento
	- usb, ethernet
	- arduino

file 6:
- Dispositivi logici
	- disp logici programmabili
- ASIC
- FPGA
	- SoC
- Dispositivi programmabili ## Tecnologia
- Dispositivi programmabili ## Caratt Generali
- Dispositivi programmabili ## Classificazione
	- SPLD -> PLA
	- SPLD -> PLE
	- SPLD -> PAL
	- PAL 16X8
- SPLD # Limiti 
- macrocelle
- GAL -> GAL 22v10
- Logica Programmazione
- GAL -> GAL 22RA10
- GAL ## Limiti
- PAL/GAL programmazione
	- esempio programmazione 
- CPLD ## Tecnologia (da GAL a CPLD)
- CPLD ## blocco logico
	- modello timing
- FPGA
- ASIC
	-  FPGA/ASIC - sviluppo
- linguaggi
	- VHDL

file 7:
- design flow
- intro to vhdl
	- modellizzazione
- design units
	- entity+architecture
	- libreries
	- operatori e funzioni
- signals
- processes
	- simulazione, equivalenze
- variabili
- sequential statements + processes
- macchine a stati finiti