![[Pasted image 20231216101215.png]]

serve set/reset perchè potrebbero non partire da uno stato noto

c'è una intrinseca indeterminazione se in corrispondenza del ingresso -> memoria l'ingresso sta anch'esso cambiando