Devono avere alta resistenza d'ingresso e bassa d'uscita.
*Immunità al rumore*: superiore ai 100mV
*Prob di guasto*: di un dispositivo elettronico è $1/10^6$

Alimentatori non sono tutti uguali.
Un disturbo all'alimentazione equivale a un disturbo sul segnale, e a uno sulla massa a