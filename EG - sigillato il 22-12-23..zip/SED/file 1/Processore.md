Macchina sincrona. Tanti dispositivi che ricevono segnali in contemporanea secondo un impulso di CLK.

Serve fan-out elevatissimo.