![[Pasted image 20231115150711.png]]

Il ritardo generato da 2N porte è pari a $N\cdot(T_{phl}+T_{plh})$
Il ritardo del circuito RC dipende dalla tensione dopo la commutazione di $V_{0}$ all'istante 0+, tra $V_{ol}$ e $V_{oh}$ e viceversa.
>HP: impedenza IN infinita per il ricevitore
![[Pasted image 20231115150913.png]]



