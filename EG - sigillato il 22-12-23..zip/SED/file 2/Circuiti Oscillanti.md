L'oscillatore ad anello a 2N+1 porte NOT oscilla con periodo (2N+1)(T_phl+T_plh)

>Il ritardo del circuito RC si comporta come <u>sopra</u>

![[Pasted image 20231115151119.png]]

## Oscillatore basato su 74HC132

pagina 23 del file 2