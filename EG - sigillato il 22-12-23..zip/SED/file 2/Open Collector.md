A causa del collettore aperto, serve una resistenza esterna di *pull-up* per ricreare il livello "1". 
![[Pasted image 20231111105829.png]]
$R_{p} >> R_{op}\sim R_{og}$ implica un livello "1" molto più debole di "0". 
La capacità di carico $C_{l}$ si scarica velocemente su $R_{og}$ mentre si carica lenta su $R_{p}$ (livello "Z").

#### Traslatore 3.3-5
>L'open collector può agire da traslatore del livello "1" => da logiche 3.3 a logiche a 5V
![[Pasted image 20231111111208.png]]
![[Pasted image 20231111111227.png]]
