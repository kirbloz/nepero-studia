Famiglia logica Bipolar-CMOS
Dispositivi che nascono negli anni 90

La più famosa è la **BCT**: si sfrutta tanto per pilotare i bus (bus driver) e ha elevate correnti di uscita $24 \div 64 \text{mA}$

Famiglia advanced **ABT**
Famiglia con alimentazione a $3.3\text{V}$ (compatibile con TTL) è **LVT**

Quella fully-TTL-compatible (in e out) è **LCX**
![[Pasted image 20231106231712.png]]