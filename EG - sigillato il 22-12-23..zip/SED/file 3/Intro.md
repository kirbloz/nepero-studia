Definizione di [[Famiglie Logiche]]
Tecnologie bipolari:
RTL, DTL, TTL.

Tecologie MOS:
cMOS

Si realizzano le [[Funzioni logiche]]
![[Pasted image 20231106231909.png]]
FCMOS: l'elemento switch 
![[Pasted image 20231106232004.png]]

---

![[Pasted image 20231106231223.png]]
![[Pasted image 20231106231232.png]]

