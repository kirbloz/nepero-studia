Utilizzato nei dispositivi sequenziali.
Può essere sia sincrono che asincrono.
![[Pasted image 20231204235713.png]]
### Sincrono: Rs
Il circuito agirà - in attivo basso - sull'uscita quando permesso da EN.
>Quindi se Rs manda un "1" e EN è anche "1"

### Asincrono: Ra
Il circuito agirà - in attivo basso - sull'uscita indipendetemente che sia permesso da EN.
>Qualvolta Ra sia "1", con EN "X"