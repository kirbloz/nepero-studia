La famiglia 74XX85 ha un tempo di propagazione massimo fisso a 45ns.

- Si può connettere comparatori in cascata per effettuare comparazioni a byte
  >Guardo i 4 bit meno signif solo se i 4 più signif sono uguali
  
  ![[Pasted image 20231203185520.png]]
Osservo che gli ingressi con $A>B$, $A<B$, $A=B$ agiscono se e solo se $A_i=B_i$ per ogni $i$.


  ---
  Questa roba non so cosa voglia dire:
  ![[Pasted image 20231203185445.png]]