Partiamo dai convertitori di codice
- [[Encoder e Decoder]]
- [[Sommatore]]
I contatori sono alla base di tutto perchè scandiscono l'avanzare degli stati e le nostre tecnologie complesse elettroniche oggi sono tutte macchine sincrone.
- [[Contatore]]


---

### Verso il sequenziale
Come capisco se è una funzione combinatoria o sequenziale?
Boh non ho preso appunti, attendo di mandare una mail alla prof o chiederle.
