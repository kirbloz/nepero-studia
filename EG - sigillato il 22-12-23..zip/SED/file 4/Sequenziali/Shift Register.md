![[Pasted image 20231205235358.png]]
![[Pasted image 20231205235427.png]]
sembra un contatore anche sto coso
qui una mappina dei segnali

![[Pasted image 20231205235326.png]]
![[Pasted image 20231205235457.png]]
