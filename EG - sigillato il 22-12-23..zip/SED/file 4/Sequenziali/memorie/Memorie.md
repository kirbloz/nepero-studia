Le memorie sono un tipo di dispositivo [[MSI]]
### PLE
Rimando dalle SPLD PLE.
![[Pasted image 20231201160043.png]]


Ci sono le memorie:
- [[SRAM]]
- [[DRAM]] 