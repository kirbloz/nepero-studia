Programmable Read Only Memory.
Come la ROM ma stavolta non è il costruttore a programmarla: bensì l'utente. Solo una volta.
- Non si cancella
- Può essere programmata tramite logica *fuse* e *antifuse*. Vedi [[ROM]] per saperne di più su queste due.

![[Pasted image 20231205232549.png]]