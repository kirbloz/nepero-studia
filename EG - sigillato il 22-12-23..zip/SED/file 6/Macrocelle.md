![[Pasted image 20231202100522.png]] [^1]
Particolare stadio di uscita per dispositivi programmabili che conferisce flessibilità al componente.





[^1]: MaC GAL 22v10