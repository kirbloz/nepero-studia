Esempio alla slide 24
![[Pasted image 20231202154454.png]]

![[Pasted image 20231202154504.png]]

![[Pasted image 20231202154512.png]]

![[Pasted image 20231202154521.png]]

![[Pasted image 20231202154527.png]]

---

![[Pasted image 20231202154545.png]]