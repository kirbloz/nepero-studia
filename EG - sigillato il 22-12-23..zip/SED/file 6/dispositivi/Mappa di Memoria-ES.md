Consegna:
![[Pasted image 20231202154258.png]]

---

![[Pasted image 20231202154011.png]]
Mi serve un dispositivo programmabile che generi questi tre segnali (CsRAM, CsEPROM, CsDISP)

![[Pasted image 20231202154141.png]]
![[Pasted image 20231202154149.png]]
![[Pasted image 20231202154159.png]]



---
Osservazioni:
![[Pasted image 20231202154222.png]]

![[Pasted image 20231202154058.png]]